<?php
/**
 * The front page template file
 *
 * If the user has selected a static page for their homepage, this is what will
 * appear.
 * 
 * @link http://codex.wordpress.org/Template_Hierarchy
 */
get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
        <?php if ( have_posts() ) { ?>
            <header class="page-header">
                <h2 class="page-title"><?php _e( 'Latest Chapters', 'mangastarter' ); ?></h2>
            </header><!-- .page-header -->
        <?php } ?>
        
        <?php
        if ( have_posts() ) {
            while ( have_posts() ) { the_post();
                get_template_part( 'components/index/content', 'index' );
            }
        } else {
            get_template_part( 'components/post/content', 'none' );
        }
        ?>
        
    </main><!-- #main -->
    <?php get_sidebar(); ?>
</div><!-- #primary -->

<?php get_footer(); ?>