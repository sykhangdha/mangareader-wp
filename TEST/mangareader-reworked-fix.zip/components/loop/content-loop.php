<?php
/**
 * Displays content for the index, front page
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 */
$relationship = get_field('manga');
?>

<?php
foreach ($relationship as $parent) {
    $mangas_post = get_post($parent->ID); // Get the "mangas" post associated with this chapter
    $mangas_name = $mangas_post->post_title; // Get the title of the "mangas" post
    $mangas_link = get_permalink($parent->ID); // Get the link to the "mangas" post
    ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <div class="uk-grid uk-grid-small uk-margin-bottom">
            <div class="uk-width-small-1-6 uk-width-medium-3-10 chapter-thumb">
                <a href="<?php echo site_url(); ?>/manga/<?php echo $parent->post_name; ?>/<?php echo $post->post_name; ?>" title="<?php the_title(); ?>">
                    <?php echo get_the_post_thumbnail($parent->ID, 'thumbnail', array('alt' => get_the_title())); ?>
                </a>
            </div>

            <div class="uk-width-small-5-6 uk-width-medium-7-10 chapter-content">
                <div>
                    <a href="<?php echo site_url(); ?>/manga/<?php echo $parent->post_name; ?>/<?php echo $post->post_name; ?>" title="<?php the_title(); ?>">
                        <h3><?php the_title(); ?></h3>
                    </a>
                </div>

                <?php if (get_field('title')) { ?>
                    <div>
                        <small><i class="uk-icon-file"></i> "<?php the_field('title'); ?>"</small>
                    </div>
                <?php } ?>

                <div class="post-date-container">
                    <small><i class="uk-icon-clock-o"></i> <?php the_time('F d, Y'); ?></small>
                </div>
                <?php if ($mangas_name) { ?>
                    <div class="mangas-name-container">
                        <i class="uk-icon-book"></i> <a href="<?php echo esc_url($mangas_link); ?>"><?php echo $mangas_name; ?></a>
                    </div>
                <?php } ?>
            </div>
        </div>
    </article>
<?php
}
?>
