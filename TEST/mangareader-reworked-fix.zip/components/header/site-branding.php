<?php
/**
 * Displays header site branding
 */
?>
<div class="uk-width-large-3-10 uk-width-small-1-1">
	<h1 class="site-title">
		<?php mangastarter_custom_logo(); ?>
	</h1>
</div>