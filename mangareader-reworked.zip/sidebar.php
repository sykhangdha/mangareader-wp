<?php
/**
 * The sidebar containing the main widget area
 */
?>

<aside id="sidebar" class="widget-area uk-width-small-1-1 uk-width-medium-3-10" role="complementary">
    <?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- end sidebar -->