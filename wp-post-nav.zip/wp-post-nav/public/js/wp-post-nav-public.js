/**
	 * Public facing JS of WP Post Nav
	 *
	 * @link:       https://wppostnav.com
	 * @since      0.0.1
	 *
	 * @package    wp_post_nav
	 * @subpackage wp_post_nav/admin/partials
	 */
	 
(function( $ ) {
	'use strict';

	

})( jQuery );
