<?php
/**
 * Register the taxonomy Authors
 */
function otakuhub_manga_taxes_authors() {
    $labels = array(
        'name'                       => _x( 'Authors', 'Taxonomy General Name', 'otakuhub-manga' ),
        'singular_name'              => _x( 'Author', 'Taxonomy Singular Name', 'otakuhub-manga' ),
        'menu_name'                  => __( 'Authors', 'otakuhub-manga' ),
    );
    $rewrite = array(
        'slug'                       => 'authors',
        'with_front'                 => true,
        'hierarchical'               => false,
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => false,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'query_var'                  => 'authors',
        'has_archive'       		 => true,
        'rewrite'                    => $rewrite,
        'show_in_rest'               => true,
    );
    register_taxonomy( 'authors', array( 'mangas' ), $args );
}