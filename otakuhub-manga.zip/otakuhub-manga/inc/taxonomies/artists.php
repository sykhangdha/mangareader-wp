<?php
/**
 * Register the taxonomy Artists
 */
function otakuhub_manga_taxes_artists() {
    $labels = array(
        'name'                       => _x( 'Artists', 'Taxonomy General Name', 'otakuhub-manga' ),
        'singular_name'              => _x( 'Artist', 'Taxonomy Singular Name', 'otakuhub-manga' ),
        'menu_name'                  => __( 'Artists', 'otakuhub-manga' ),
    );
    $rewrite = array(
        'slug'                       => 'artists',
        'with_front'                 => true,
        'hierarchical'               => false,
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => false,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'query_var'                  => 'artists',
        'has_archive'       		 => true,
        'rewrite'                    => $rewrite,
        'show_in_rest'               => true,
    );
    register_taxonomy( 'artists', array( 'mangas' ), $args );
}